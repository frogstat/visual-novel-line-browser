import type {Characters, SelectedCharacter, VoiceFilter} from "../../utils/types.ts";
import CharacterSelect from "./CharacterSelect.tsx";
import type {ChangeEvent} from "react";
import {getUIName} from "../../utils/uiLocale.ts";

type SearchBarProps = {
    query: string;
    setQuery: (searchText: string) => void;
    characters: Characters | null;
    selectCharacter: (e: ChangeEvent<HTMLSelectElement>) => void;
    currentLanguage: string;
    favoritesOnly: boolean;
    toggleFavoritesOnly: () => void;
    voiceFilter: VoiceFilter;
    setVoiceFilter: (filter: VoiceFilter) => void;
    selectedCharacter: SelectedCharacter | null;
};

function SearchTools({
                         query,
                         setQuery,
                         characters,
                         selectCharacter,
                         currentLanguage,
                         favoritesOnly,
                         toggleFavoritesOnly,
                         voiceFilter,
                         setVoiceFilter,
                         selectedCharacter
                     }: SearchBarProps) {

    return (
        <div className="search-tools">
            <div className="search-tools-top">
                <div className="voice-filter">
                    <button className={"voice-filter-button " + (voiceFilter === "voiced" ? "button-active" : "")}
                            onClick={() => setVoiceFilter("voiced")}>{getUIName(currentLanguage, "voicedOnly")}
                    </button>
                    <button className={"voice-filter-button " + (voiceFilter === "unvoiced" ? "button-active" : "")}
                            onClick={() => setVoiceFilter("unvoiced")}>{getUIName(currentLanguage, "unvoicedOnly")}
                    </button>
                    <button className={"voice-filter-button " + (voiceFilter === "any" ? "button-active" : "")}
                            onClick={() => setVoiceFilter("any")}>{getUIName(currentLanguage, "voicedAny")}
                    </button>
                </div>
                <button className={favoritesOnly ? "button-active" : ""}
                        onClick={toggleFavoritesOnly}>{getUIName(currentLanguage, "favoritesOnly")}</button>
            </div>

            <div className="search-bar">

                <input
                    className="search-query-bar"
                    type="text"
                    placeholder={getUIName(currentLanguage, "searchQuote")}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                />
                {(characters || selectedCharacter) && (
                    <CharacterSelect
                        characters={characters ?? []}
                        currentLanguage={currentLanguage}
                        selectCharacter={selectCharacter}
                        selectedCharacter={selectedCharacter}
                    />
                )}


            </div>
        </div>
    )

}

export default SearchTools;