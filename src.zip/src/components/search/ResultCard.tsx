import downloadIcon from "../../assets/download.svg"
import type {Characters, Line, SelectedCharacter} from "../../utils/types.ts";
import playIcon from "../../assets/play-icon.svg"
import searchIcon from "../../assets/search-icon.svg"
import favoriteIcon from "../../assets/favorited.svg"
import notFavoritedIcon from "../../assets/not-favorited.svg"
import {getLineValue} from "../../utils/lineParser.ts";
import SvgIcon from "../SvgIcon.tsx";


type LineCardProps = {
    // Shared props
    lineIndex: number;
    line: Line,
    playVoice: (voiceFile: string | null | undefined) => void,
    currentLanguage: string,
    favorites: number[],
    toggleFavorite: (favoriteIndex: number) => void,
    downloadVoiceFile: (name: string | null | undefined) => void,

    // Result Card only
    showContextView: ((originIndex: number) => void) | null,
    setSelectedCharacter: ((name: SelectedCharacter) => void) | null,
    characters: Characters | null,

    // Context Card only
    isCurrent: boolean | null;
    originLineRef: any | null;
}

function ResultCard({
                        line,
                        playVoice,
                        currentLanguage,
                        favorites,
                        toggleFavorite,
                        lineIndex,
                        showContextView,
                        isCurrent,
                        originLineRef,
                        downloadVoiceFile,
                        setSelectedCharacter,
                        characters
                    }: LineCardProps) {

    function isFavorited() {
        return favorites.includes(lineIndex)
    }

    function handleSpeakerClick(): void {
        if (!setSelectedCharacter) {
            return;
        }

        const name = getLineValue(line, "speaker", currentLanguage)

        const id = characters ?
            Object.keys(characters).find(currentId => {
                const charName = currentLanguage ?
                    characters[currentId][`name_${currentLanguage}`] :
                    characters[currentId].name;
                return charName && name.includes(charName)
            })
            : null;

        setSelectedCharacter({
            id: id ?? null,
            name: name
        })
    }

    return (
        <div className={`result-card ${isCurrent && originLineRef ? "context-card-current" : ""}`}
             ref={isCurrent ? originLineRef : null}>
            <div className="result-card-left">

                {getLineValue(line, "speaker", currentLanguage) && (
                    <p className="result-card-speaker" style={setSelectedCharacter !== null ? {cursor: "pointer"} : {}}
                       onClick={handleSpeakerClick}>
                        {getLineValue(line, "speaker", currentLanguage)}
                    </p>
                )}

                <p>{getLineValue(line, "text", currentLanguage)}</p>

            </div>

            <div className="result-card-right">
                <div className="result-card-actions">
                    {line.voice_file && (
                        <>
                            <button className="card-button" onClick={() => playVoice(line.voice_file)}>
                                <SvgIcon label={"play"} icon={playIcon}/>
                            </button>
                            <button className="card-button" onClick={() => downloadVoiceFile(line.voice_file)}>
                                <SvgIcon
                                    label={"download voice file"}
                                    icon={downloadIcon}
                                />
                            </button>
                        </>
                    )}

                    <button className="card-button" onClick={() => toggleFavorite(lineIndex)}>
                        <SvgIcon
                            label={isFavorited() ? "favorite" : "unfavorite"}
                            icon={isFavorited() ? favoriteIcon : notFavoritedIcon}
                        />
                    </button>

                    {showContextView && (
                        <button className="card-button" onClick={() => showContextView(lineIndex)}>
                            <SvgIcon
                                label={"search"}
                                icon={searchIcon}
                            />
                        </button>
                    )}


                </div>
                <span className="result-index">{lineIndex + 1}</span>
            </div>

        </div>
    );
}

export default ResultCard