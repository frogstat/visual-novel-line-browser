import Header from "./components/Header.tsx";
import ResultList from "./components/search/ResultList.tsx";
import SearchTools from "./components/search/SearchTools.tsx";
import ContextPanel from "./components/search/ContextPanel.tsx";
import {useGameData} from "./hooks/useGameData.ts";
import {useVoicePlayer} from "./hooks/useVoicePlayer.ts";
import {useMusicPlayer} from "./hooks/useMusicPlayer.ts";
import {useContextView} from "./hooks/useContextView.ts";
import type {Game} from "./utils/types.ts";
import {useSearch} from "./hooks/useSearch.ts";
import {useLoaderData} from "react-router-dom";



function GameView() {
    const game: Game = useLoaderData();

    const {
        lines,
        voiceBasePath,
        musicBasePath,
        characters,
        languages,
        currentLanguage,
        changeLanguage,
        error,
        codeLength
    } = useGameData(game.folderName);

    const {
        downloadVoiceFile,
        playVoice
    } = useVoicePlayer(voiceBasePath);

    const {
        tracks,
        currentTrack,
        volume,
        changeVolume,
        isPlaying,
        togglePause,
        playNextTrack
    } = useMusicPlayer(musicBasePath);

    const {
        contextView,
        showContextView,
        closeContext,
        navigateContextView,
        originLineRef,
        contextMenuRef
    } = useContextView(lines?.length ?? 0);

    const {
        voiceFilter,
        setVoiceFilter,
        favorites,
        toggleFavorite,
        favoritesOnly,
        toggleFavoritesOnly,
        query,
        setQuery,
        selectCharacter,
        resultIndices,
        setSelectedCharacter,
        selectedCharacter,
        topOfPageRef
    } = useSearch(game.folderName, languages, lines, codeLength, characters);


    return (
        <main className="app" ref={topOfPageRef}>
            <div className="game-box">
                <Header
                    gameName={game.title}
                    languages={languages}
                    currentLanguage={currentLanguage}
                    changeLanguage={changeLanguage}
                    tracks={tracks}
                    musicProps={{
                        currentTrack,
                        volume,
                        changeVolume,
                        isPlaying,
                        togglePause,
                        playNextTrack
                    }}
                />

                <SearchTools
                    query={query}
                    setQuery={setQuery}
                    characters={characters}
                    selectCharacter={selectCharacter}
                    currentLanguage={currentLanguage}
                    favoritesOnly={favoritesOnly}
                    toggleFavoritesOnly={toggleFavoritesOnly}
                    voiceFilter={voiceFilter}
                    setVoiceFilter={setVoiceFilter}
                    selectedCharacter={selectedCharacter}
                />

                <ResultList
                    resultIndices={resultIndices}
                    lines={lines}
                    currentLanguage={currentLanguage}
                    playVoice={playVoice}
                    error={error}
                    showContextView={showContextView}
                    favorites={favorites}
                    toggleFavorite={toggleFavorite}
                    setSelectedCharacter={setSelectedCharacter}
                    downloadVoiceFile={downloadVoiceFile}
                    characters={characters}
                />
            </div>

            {contextView && (
                <ContextPanel
                    lines={lines ?? []}
                    contextView={contextView}
                    closeContext={closeContext}
                    navigateContextView={navigateContextView}
                    languages={languages}
                    currentLanguage={currentLanguage}
                    changeLanguage={changeLanguage}
                    playVoice={playVoice}
                    originLineRef={originLineRef}
                    contextMenuRef={contextMenuRef}
                    favorites={favorites}
                    toggleFavorite={toggleFavorite}
                    downloadVoiceFile={downloadVoiceFile}
                />
            )}
        </main>
    )
}

export default GameView;