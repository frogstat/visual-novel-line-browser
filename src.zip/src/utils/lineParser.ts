import type {Characters, Line} from "./types.ts";


/**
 *
 * @param line - The line in question
 * @param language - A 2 letter language code such as jp, en, se, ch
 */
export function resolveTextFromLanguage(line: Line, language: string): string | null | undefined {
    return line[`text_${language}`];
}


/**
 * Returns a character name from the value of a voice file. Returns null if nothing is required data doesn't exist.
 * @param voiceFile - The voice file for the line (e.g. HAY45666.ogg where HAY stands for Hayato)
 * @param characters - A list of character codes and their matching character names.
 * @param codeLength - How many chars in the voice file name are the code. (e.g. MAK_COMMON_033.ogg will have a code length of 3)
 * @param language - The current language
 */
function resolveCharacterNameFromCode(voiceFile: string, characters: Characters, codeLength: number, language: string) {

    const characterCode: string = getCharacterCodeFromVoiceLine(voiceFile, codeLength);
    if (characterCode in characters) {
        return getCharacterName(characters, characterCode, language);
    }

    return null;
}

function resolveSpeakerFromLine(line: Line, language: string): string | null | undefined {
    return getLineValue(line, "speaker", language)
}

export function resolveSpeaker(voiceFile: string | undefined | null, characters: any, codeLength: number, language: string, line: Line) {
    const characterName = resolveSpeakerFromLine(line, language)

    if (!voiceFile || !codeLength) {
        return characterName;
    }

    const resolvedName = resolveCharacterNameFromCode(voiceFile, characters, codeLength, language);

    if (!resolvedName) {
        return characterName;
    }

    return resolvedName === characterName ? resolvedName : `${resolvedName} ( ${characterName} )`

}

export function getCharacterCodeFromVoiceLine(voiceFile: string, codeLength: number) {
    return voiceFile.slice(0, codeLength);
}


export function getLineValue(line: Line, key: "speaker" | "text",  language?: string): string {
    const value = language
        ? line[`${key}_${language}` as keyof Line]
        : line[key];
    return value ? value : "";
}

export function getCharacterName(characters: Characters, characterCode: string, language?: string): string {
    const character = characters[characterCode];

    const characterName = language ?
        character[`name_${language}`]
        : character[`name`];

    return characterName ? characterName : "";
}

