export type Line = {
    voice_file?: string | null;
    speaker?: string | null;
    text?: string | null;
    [key: `speaker_${string}`]: string | null | undefined;
    [key: `text_${string}`]: string | null | undefined;
};

export type Character = {
    name?: string | null | undefined;
    [key: `name_${string}`]: string | null | undefined;
}

export type SelectedCharacter = {
    id: string | null,
    name: string
}

export type Characters = Record<string, Character>;

export type ContextView = {
    originIndex: number,
    centerIndex: number,
    results: number[]
}

export type Game = {
    folderName: string,
    title: string
}

export type VoiceFilter = "any" | "voiced" | "unvoiced"

export type Metadata = {
    languages?: string[],
    hasCharacterCode?: boolean
}

export type VoiceIndex = Record<string, [number, number]>